#include "p0p1_client.h"
#include "ui_p0p1_client.h"
#include "infowindow.h"
#include "mainwindow.h"
#include <QDateTime>
#include <QJsonObject>
#include <QJsonDocument>

P0P1_Client::P0P1_Client(QString user_name,QString other_user_name,QString usr_name,QString other_name,QTcpSocket *socket_,QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::P0P1_Client),socket(socket_)
{
    ui->setupUi(this);
    client_user_name=user_name;
    opp_user_name=other_user_name;
    client_name=usr_name;
    opp_name=other_name;
    ui->name->setText(opp_name);
    connect(socket, &QTcpSocket::readyRead, this, &P0P1_Client::readMessage);
    connect(socket, QOverload<QAbstractSocket::SocketError>::of(&QAbstractSocket::errorOccurred),
            this, &P0P1_Client::displayError);
    //connect(ui->connectButton, &QPushButton::clicked, this, &P0P1_Client::connectToServer);
    connect(ui->sendButton, &QPushButton::clicked, this, &P0P1_Client::sendMessage);
    socket->write(client_user_name.toUtf8());
    // QString ipAddress="10.129.210.11";//10.6.220.60
    // quint16 port=1234;
    // socket->connectToHost(ipAddress,port);
}

P0P1_Client::~P0P1_Client()
{
    delete ui;
}

QString P0P1_Client::client_Send_p0p1_Msg_ToJson(const QString &client_id, const QString &p0p1_host, const QString &text)
{
    // 创建JSON对象
    QJsonObject jsonObj;
    jsonObj["client_id"] = client_id;
    jsonObj["mode"] = "p0p1";
    jsonObj["do"] = "send";
    jsonObj["p0p1_host"] = p0p1_host;
    jsonObj["text"] = text;

    // 将JSON对象转换为JSON文档
    QJsonDocument jsonDoc(jsonObj);

    // 将JSON文档转换为QString（JSON字符串）
    QString jsonString = jsonDoc.toJson(QJsonDocument::Compact);

    return jsonString;
}

QString P0P1_Client::client_Request_p0p1_Msg_ToJson(const QString &client_id, const QString &p0p1_host)
{
    // 创建JSON对象
    QJsonObject jsonObj;
    jsonObj["client_id"] = client_id;
    jsonObj["mode"] = "p0p1";
    jsonObj["do"] = "request";
    jsonObj["p0p1_host"] = p0p1_host;

    // 将JSON对象转换为JSON文档
    QJsonDocument jsonDoc(jsonObj);

    // 将JSON文档转换为QString（JSON字符串）
    QString jsonString = jsonDoc.toJson(QJsonDocument::Compact);

    return jsonString;
}



QJsonObject P0P1_Client::jsonToData(const QString &jsonString)
{
    // 将QString转换为QByteArray
    QByteArray jsonData = jsonString.toUtf8();

    // 将QByteArray解析为JSON文档
    QJsonDocument jsonDoc = QJsonDocument::fromJson(jsonData);

    // 将JSON文档转换为JSON对象
    QJsonObject jsonObj = jsonDoc.object();

    return jsonObj;
}

// void P0P1_Client::connectToServer()
// {
//     QString ipAddress = ui->ipAddressLineEdit->text();
//     quint16 port = ui->portLineEdit->text().toUShort();
//     socket->connectToHost(ipAddress, port);
// }

void P0P1_Client::readMessage()
{
    QString text=socket->readAll();
    QJsonObject json=jsonToData(text);
    QString host_user_name=json["p0p1_host"].toString();
    QString message=json["text"].toString();
    if(host_user_name==opp_user_name)
        ui->log->append(message);

    // QString message = socket->readAll();
    // QString total_message=socket->readAll();
    // if(!total_message.isEmpty()&&total_message!=MainWindow::message_str)
    //     MainWindow::message_str=total_message;
    // QString name=MainWindow::message_str.section(":",0,0);
    // QString message=MainWindow::message_str.section(":",1);
    //qDebug()<<MainWindow::message_str<<"\n";
    // if(name==opp_name)
    // {
    //     ui->log->append(name+":"+message);
    // }
    //emit dataReceived(name,message);
    //ui->log->append("Server: " + message);
}

void P0P1_Client::sendMessage()
{
    QDateTime dateTime=QDateTime::currentDateTime();
    QString date=dateTime.date().toString("yyyy-M-d");
    QString time=dateTime.time().toString("h:mm:ss");
    QString message = ui->messageEdit->toPlainText();
    QString text=date+" "+time+"\n"+client_name+": " + message;
    //client_user_name
    //opp_user_name
    QString jsonString=client_Send_p0p1_Msg_ToJson(client_user_name,opp_user_name,text);
    socket->write(jsonString.toUtf8());//toUtf8()
    //socket->write((opp_name+": "+message).toUtf8());
    //socket->write(message.toUtf8());
    //ui->log->append(text);
    ui->messageEdit->clear();
}

void P0P1_Client::displayError(QAbstractSocket::SocketError socketError)
{
    Q_UNUSED(socketError)
    ui->log->append("Error: " + socket->errorString());
}

void P0P1_Client::on_toolButton_clicked()
{
    infoWindow *info=new infoWindow(opp_name);
    info->setWindowFlag(Qt::MSWindowsFixedSizeDialogHint);
    info->show();
}

