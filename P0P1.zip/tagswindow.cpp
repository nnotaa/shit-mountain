#include "tagswindow.h"
#include "ui_tagswindow.h"
#include "mainwindow.h"
#include <QFileDialog>
#include <QSaveFile>
#include <QException>
#include <QMessageBox>
#include <QTextBlock>

tagswindow::tagswindow(QPlainTextEdit *txtEdit_,QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::tagswindow),txtEdit(txtEdit_)
{
    ui->setupUi(this);
    txtEdit->clear();
    open();
}

tagswindow::~tagswindow()
{
    delete ui;
}

void tagswindow::open()
{
    QDir currentDir=QDir::current();
    QString dirPath="current";
    if(!currentDir.exists(dirPath))
    {
        if(!currentDir.mkdir(dirPath))
            return;
    }
    QFile tagsFile(currentDir.filePath(dirPath+"/tags.txt"));
    if(!tagsFile.exists())
        return;
    if(!tagsFile.open(QIODevice::ReadOnly | QIODevice::Text))
        return;
    QTextStream tagstxt(&tagsFile);
    QString tagsstr=tagstxt.readAll();
    tagsstr[0]=='1'?ui->pushButton->setChecked(true):ui->pushButton->setChecked(false);
    tagsstr[1]=='1'?ui->pushButton_2->setChecked(true):ui->pushButton_2->setChecked(false);
    tagsstr[2]=='1'?ui->pushButton_3->setChecked(true):ui->pushButton_3->setChecked(false);
    tagsstr[3]=='1'?ui->pushButton_4->setChecked(true):ui->pushButton_4->setChecked(false);
    tagsstr[4]=='1'?ui->pushButton_5->setChecked(true):ui->pushButton_5->setChecked(false);
    tagsstr[5]=='1'?ui->pushButton_6->setChecked(true):ui->pushButton_6->setChecked(false);
    tagsstr[6]=='1'?ui->pushButton_7->setChecked(true):ui->pushButton_7->setChecked(false);
    tagsstr[7]=='1'?ui->pushButton_8->setChecked(true):ui->pushButton_8->setChecked(false);
    tagsstr[8]=='1'?ui->pushButton_9->setChecked(true):ui->pushButton_9->setChecked(false);
    tagsstr[9]=='1'?ui->pushButton_10->setChecked(true):ui->pushButton_10->setChecked(false);
    tagsstr[10]=='1'?ui->pushButton_11->setChecked(true):ui->pushButton_11->setChecked(false);
    tagsstr[11]=='1'?ui->pushButton_12->setChecked(true):ui->pushButton_12->setChecked(false);
    tagsstr[12]=='1'?ui->pushButton_13->setChecked(true):ui->pushButton_13->setChecked(false);
    tagsstr[13]=='1'?ui->pushButton_14->setChecked(true):ui->pushButton_14->setChecked(false);
    tagsstr[14]=='1'?ui->pushButton_15->setChecked(true):ui->pushButton_15->setChecked(false);
    tagsstr[15]=='1'?ui->pushButton_16->setChecked(true):ui->pushButton_16->setChecked(false);
    tagsstr[16]=='1'?ui->pushButton_17->setChecked(true):ui->pushButton_17->setChecked(false);
    tagsstr[17]=='1'?ui->pushButton_18->setChecked(true):ui->pushButton_18->setChecked(false);
    tagsstr[18]=='1'?ui->pushButton_19->setChecked(true):ui->pushButton_19->setChecked(false);
    tagsstr[19]=='1'?ui->pushButton_20->setChecked(true):ui->pushButton_20->setChecked(false);
    tagsstr[20]=='1'?ui->pushButton_21->setChecked(true):ui->pushButton_21->setChecked(false);
    tagsstr[21]=='1'?ui->pushButton_22->setChecked(true):ui->pushButton_22->setChecked(false);
    tagsstr[22]=='1'?ui->pushButton_23->setChecked(true):ui->pushButton_23->setChecked(false);
    tagsstr[23]=='1'?ui->pushButton_24->setChecked(true):ui->pushButton_24->setChecked(false);
    tagsstr[24]=='1'?ui->pushButton_25->setChecked(true):ui->pushButton_25->setChecked(false);
    tagsstr[25]=='1'?ui->pushButton_26->setChecked(true):ui->pushButton_26->setChecked(false);
    tagsstr[26]=='1'?ui->pushButton_27->setChecked(true):ui->pushButton_27->setChecked(false);
    tagsstr[27]=='1'?ui->pushButton_28->setChecked(true):ui->pushButton_28->setChecked(false);
    tagsstr[28]=='1'?ui->pushButton_29->setChecked(true):ui->pushButton_29->setChecked(false);
    tagsstr[29]=='1'?ui->pushButton_30->setChecked(true):ui->pushButton_30->setChecked(false);
    tagsstr[30]=='1'?ui->pushButton_31->setChecked(true):ui->pushButton_31->setChecked(false);
    tagsstr[31]=='1'?ui->pushButton_32->setChecked(true):ui->pushButton_32->setChecked(false);
    tagsstr[32]=='1'?ui->pushButton_33->setChecked(true):ui->pushButton_33->setChecked(false);
    tagsstr[33]=='1'?ui->pushButton_34->setChecked(true):ui->pushButton_34->setChecked(false);
    tagsstr[34]=='1'?ui->pushButton_35->setChecked(true):ui->pushButton_35->setChecked(false);
    tagsstr[35]=='1'?ui->pushButton_36->setChecked(true):ui->pushButton_36->setChecked(false);
    tagsstr[36]=='1'?ui->pushButton_37->setChecked(true):ui->pushButton_37->setChecked(false);
    tagsstr[37]=='1'?ui->pushButton_38->setChecked(true):ui->pushButton_38->setChecked(false);
    tagsstr[38]=='1'?ui->pushButton_39->setChecked(true):ui->pushButton_39->setChecked(false);
    tagsstr[39]=='1'?ui->pushButton_40->setChecked(true):ui->pushButton_40->setChecked(false);
    tagsstr[40]=='1'?ui->pushButton_41->setChecked(true):ui->pushButton_41->setChecked(false);
    tagsstr[41]=='1'?ui->pushButton_42->setChecked(true):ui->pushButton_42->setChecked(false);
    tagsstr[42]=='1'?ui->pushButton_43->setChecked(true):ui->pushButton_43->setChecked(false);
    tagsstr[43]=='1'?ui->pushButton_44->setChecked(true):ui->pushButton_44->setChecked(false);
    tagsstr[44]=='1'?ui->pushButton_45->setChecked(true):ui->pushButton_45->setChecked(false);
    tagsstr[45]=='1'?ui->pushButton_46->setChecked(true):ui->pushButton_46->setChecked(false);
    tagsstr[46]=='1'?ui->pushButton_47->setChecked(true):ui->pushButton_47->setChecked(false);
    tagsstr[47]=='1'?ui->pushButton_48->setChecked(true):ui->pushButton_48->setChecked(false);
    tagsstr[48]=='1'?ui->pushButton_49->setChecked(true):ui->pushButton_49->setChecked(false);
    tagsstr[49]=='1'?ui->pushButton_50->setChecked(true):ui->pushButton_50->setChecked(false);
    tagsstr[50]=='1'?ui->pushButton_51->setChecked(true):ui->pushButton_51->setChecked(false);
    tagsstr[51]=='1'?ui->pushButton_52->setChecked(true):ui->pushButton_52->setChecked(false);
    tagsstr[52]=='1'?ui->pushButton_53->setChecked(true):ui->pushButton_53->setChecked(false);
    tagsstr[53]=='1'?ui->pushButton_54->setChecked(true):ui->pushButton_54->setChecked(false);
    tagsstr[54]=='1'?ui->pushButton_55->setChecked(true):ui->pushButton_55->setChecked(false);
    tagsstr[55]=='1'?ui->pushButton_56->setChecked(true):ui->pushButton_56->setChecked(false);
    tagsstr[56]=='1'?ui->pushButton_57->setChecked(true):ui->pushButton_57->setChecked(false);
    tagsstr[57]=='1'?ui->pushButton_58->setChecked(true):ui->pushButton_58->setChecked(false);
    tagsstr[58]=='1'?ui->pushButton_59->setChecked(true):ui->pushButton_59->setChecked(false);
    tagsstr[59]=='1'?ui->pushButton_60->setChecked(true):ui->pushButton_60->setChecked(false);
    tagsstr[60]=='1'?ui->pushButton_61->setChecked(true):ui->pushButton_61->setChecked(false);
    tagsstr[61]=='1'?ui->pushButton_62->setChecked(true):ui->pushButton_62->setChecked(false);
    tagsstr[62]=='1'?ui->pushButton_63->setChecked(true):ui->pushButton_63->setChecked(false);
    //ui->pushButton->setChecked(true);
}

void tagswindow::save()
{
    QDir currentDir=QDir::current();
    QString dirPath="current";
    if(!currentDir.exists(dirPath))
    {
        if(!currentDir.mkdir(dirPath))
            return;
    }
    QFile tagsFile(currentDir.filePath(dirPath+"/tags.txt"));
    if(!tagsFile.open(QIODevice::WriteOnly | QIODevice::Text))
        return;
    QTextStream tagstxt(&tagsFile);
    tagstxt<<(ui->pushButton->isChecked()?"1":"0");
    tagstxt<<(ui->pushButton_2->isChecked()?"1":"0");
    tagstxt<<(ui->pushButton_3->isChecked()?"1":"0");
    tagstxt<<(ui->pushButton_4->isChecked()?"1":"0");
    tagstxt<<(ui->pushButton_5->isChecked()?"1":"0");
    tagstxt<<(ui->pushButton_6->isChecked()?"1":"0");
    tagstxt<<(ui->pushButton_7->isChecked()?"1":"0");
    tagstxt<<(ui->pushButton_8->isChecked()?"1":"0");
    tagstxt<<(ui->pushButton_9->isChecked()?"1":"0");
    tagstxt<<(ui->pushButton_10->isChecked()?"1":"0");
    tagstxt<<(ui->pushButton_11->isChecked()?"1":"0");
    tagstxt<<(ui->pushButton_12->isChecked()?"1":"0");
    tagstxt<<(ui->pushButton_13->isChecked()?"1":"0");
    tagstxt<<(ui->pushButton_14->isChecked()?"1":"0");
    tagstxt<<(ui->pushButton_15->isChecked()?"1":"0");
    tagstxt<<(ui->pushButton_16->isChecked()?"1":"0");
    tagstxt<<(ui->pushButton_17->isChecked()?"1":"0");
    tagstxt<<(ui->pushButton_18->isChecked()?"1":"0");
    tagstxt<<(ui->pushButton_19->isChecked()?"1":"0");
    tagstxt<<(ui->pushButton_20->isChecked()?"1":"0");
    tagstxt<<(ui->pushButton_21->isChecked()?"1":"0");
    tagstxt<<(ui->pushButton_22->isChecked()?"1":"0");
    tagstxt<<(ui->pushButton_23->isChecked()?"1":"0");
    tagstxt<<(ui->pushButton_24->isChecked()?"1":"0");
    tagstxt<<(ui->pushButton_25->isChecked()?"1":"0");
    tagstxt<<(ui->pushButton_26->isChecked()?"1":"0");
    tagstxt<<(ui->pushButton_27->isChecked()?"1":"0");
    tagstxt<<(ui->pushButton_28->isChecked()?"1":"0");
    tagstxt<<(ui->pushButton_29->isChecked()?"1":"0");
    tagstxt<<(ui->pushButton_30->isChecked()?"1":"0");
    tagstxt<<(ui->pushButton_31->isChecked()?"1":"0");
    tagstxt<<(ui->pushButton_32->isChecked()?"1":"0");
    tagstxt<<(ui->pushButton_33->isChecked()?"1":"0");
    tagstxt<<(ui->pushButton_34->isChecked()?"1":"0");
    tagstxt<<(ui->pushButton_35->isChecked()?"1":"0");
    tagstxt<<(ui->pushButton_36->isChecked()?"1":"0");
    tagstxt<<(ui->pushButton_37->isChecked()?"1":"0");
    tagstxt<<(ui->pushButton_38->isChecked()?"1":"0");
    tagstxt<<(ui->pushButton_39->isChecked()?"1":"0");
    tagstxt<<(ui->pushButton_40->isChecked()?"1":"0");
    tagstxt<<(ui->pushButton_41->isChecked()?"1":"0");
    tagstxt<<(ui->pushButton_42->isChecked()?"1":"0");
    tagstxt<<(ui->pushButton_43->isChecked()?"1":"0");
    tagstxt<<(ui->pushButton_44->isChecked()?"1":"0");
    tagstxt<<(ui->pushButton_45->isChecked()?"1":"0");
    tagstxt<<(ui->pushButton_46->isChecked()?"1":"0");
    tagstxt<<(ui->pushButton_47->isChecked()?"1":"0");
    tagstxt<<(ui->pushButton_48->isChecked()?"1":"0");
    tagstxt<<(ui->pushButton_49->isChecked()?"1":"0");
    tagstxt<<(ui->pushButton_50->isChecked()?"1":"0");
    tagstxt<<(ui->pushButton_51->isChecked()?"1":"0");
    tagstxt<<(ui->pushButton_52->isChecked()?"1":"0");
    tagstxt<<(ui->pushButton_53->isChecked()?"1":"0");
    tagstxt<<(ui->pushButton_54->isChecked()?"1":"0");
    tagstxt<<(ui->pushButton_55->isChecked()?"1":"0");
    tagstxt<<(ui->pushButton_56->isChecked()?"1":"0");
    tagstxt<<(ui->pushButton_57->isChecked()?"1":"0");
    tagstxt<<(ui->pushButton_58->isChecked()?"1":"0");
    tagstxt<<(ui->pushButton_59->isChecked()?"1":"0");
    tagstxt<<(ui->pushButton_60->isChecked()?"1":"0");
    tagstxt<<(ui->pushButton_61->isChecked()?"1":"0");
    tagstxt<<(ui->pushButton_62->isChecked()?"1":"0");
    tagstxt<<(ui->pushButton_63->isChecked()?"1":"0");
    tagsFile.close();
}

void tagswindow::output()
{
    if(ui->pushButton->isChecked()||ui->pushButton_2->isChecked()||ui->pushButton_3->isChecked()||ui->pushButton_4->isChecked()
        ||ui->pushButton_5->isChecked()||ui->pushButton_6->isChecked()||ui->pushButton_7->isChecked()||ui->pushButton_8->isChecked()
        ||ui->pushButton_9->isChecked())
    {
        txtEdit->appendPlainText("推荐：");
        if(ui->pushButton->isChecked())
            txtEdit->appendPlainText("好奇心旺盛 ");
        if(ui->pushButton_2->isChecked())
            txtEdit->appendPlainText("分享欲爆棚 ");
        if(ui->pushButton_3->isChecked())
            txtEdit->appendPlainText("减肥中 ");
        if(ui->pushButton_4->isChecked())
            txtEdit->appendPlainText("健身党 ");
        if(ui->pushButton_5->isChecked())
            txtEdit->appendPlainText("喜欢摄影 ");
        if(ui->pushButton_6->isChecked())
            txtEdit->appendPlainText("喜欢旅行 ");
        if(ui->pushButton_7->isChecked())
            txtEdit->appendPlainText("喵星人 ");
        if(ui->pushButton_8->isChecked())
            txtEdit->appendPlainText("追求三观一致 ");
        if(ui->pushButton_9->isChecked())
            txtEdit->appendPlainText("情绪稳定 ");
        txtEdit->appendPlainText("");
    }
    if(ui->pushButton_10->isChecked()||ui->pushButton_11->isChecked()||ui->pushButton_12->isChecked()||ui->pushButton_13->isChecked()
        ||ui->pushButton_14->isChecked()||ui->pushButton_15->isChecked()||ui->pushButton_16->isChecked()||ui->pushButton_17->isChecked()
        ||ui->pushButton_18->isChecked())
    {
        txtEdit->appendPlainText("个性：");
        if(ui->pushButton_10->isChecked())
            txtEdit->appendPlainText("宝藏男孩 ");
        if(ui->pushButton_11->isChecked())
            txtEdit->appendPlainText("宝藏女孩 ");
        if(ui->pushButton_12->isChecked())
            txtEdit->appendPlainText("比较佛系 ");
        if(ui->pushButton_13->isChecked())
            txtEdit->appendPlainText("幽默风趣 ");
        if(ui->pushButton_14->isChecked())
            txtEdit->appendPlainText("间歇性高冷 ");
        if(ui->pushButton_15->isChecked())
            txtEdit->appendPlainText("活泼外向 ");
        if(ui->pushButton_16->isChecked())
            txtEdit->appendPlainText("完美主义 ");
        if(ui->pushButton_17->isChecked())
            txtEdit->appendPlainText("文艺青年 ");
        if(ui->pushButton_18->isChecked())
            txtEdit->appendPlainText("在逃公主 ");
        txtEdit->appendPlainText("");
    }
    if(ui->pushButton_19->isChecked()||ui->pushButton_20->isChecked()||ui->pushButton_21->isChecked()||ui->pushButton_22->isChecked()
        ||ui->pushButton_23->isChecked()||ui->pushButton_24->isChecked()||ui->pushButton_25->isChecked()||ui->pushButton_26->isChecked()
        ||ui->pushButton_27->isChecked())
    {
        txtEdit->appendPlainText("运动：");
        if(ui->pushButton_19->isChecked())
            txtEdit->appendPlainText("夜跑 ");
        if(ui->pushButton_20->isChecked())
            txtEdit->appendPlainText("乒乓球 ");
        if(ui->pushButton_21->isChecked())
            txtEdit->appendPlainText("羽毛球 ");
        if(ui->pushButton_22->isChecked())
            txtEdit->appendPlainText("篮球少年 ");
        if(ui->pushButton_23->isChecked())
            txtEdit->appendPlainText("骑行 ");
        if(ui->pushButton_24->isChecked())
            txtEdit->appendPlainText("台球 ");
        if(ui->pushButton_25->isChecked())
            txtEdit->appendPlainText("足球迷 ");
        if(ui->pushButton_26->isChecked())
            txtEdit->appendPlainText("游泳 ");
        if(ui->pushButton_27->isChecked())
            txtEdit->appendPlainText("排球 ");
        txtEdit->appendPlainText("");
    }
    if(ui->pushButton_28->isChecked()||ui->pushButton_29->isChecked()||ui->pushButton_30->isChecked()||ui->pushButton_31->isChecked()
        ||ui->pushButton_32->isChecked()||ui->pushButton_33->isChecked()||ui->pushButton_34->isChecked()||ui->pushButton_35->isChecked()
        ||ui->pushButton_36->isChecked())
    {
        txtEdit->appendPlainText("游戏：");
        if(ui->pushButton_28->isChecked())
            txtEdit->appendPlainText("剧本杀爱好者 ");
        if(ui->pushButton_29->isChecked())
            txtEdit->appendPlainText("乐高爱好者 ");
        if(ui->pushButton_30->isChecked())
            txtEdit->appendPlainText("lol玩家 ");
        if(ui->pushButton_31->isChecked())
            txtEdit->appendPlainText("喜欢密室逃脱 ");
        if(ui->pushButton_32->isChecked())
            txtEdit->appendPlainText("手办收藏家 ");
        if(ui->pushButton_33->isChecked())
            txtEdit->appendPlainText("steam玩家 ");
        if(ui->pushButton_34->isChecked())
            txtEdit->appendPlainText("switch玩家 ");
        if(ui->pushButton_35->isChecked())
            txtEdit->appendPlainText("爱玩王者荣耀 ");
        if(ui->pushButton_36->isChecked())
            txtEdit->appendPlainText("原神，启动！ ");
        txtEdit->appendPlainText("");
    }
    if(ui->pushButton_37->isChecked()||ui->pushButton_38->isChecked()||ui->pushButton_39->isChecked()||ui->pushButton_40->isChecked()
        ||ui->pushButton_41->isChecked()||ui->pushButton_42->isChecked()||ui->pushButton_43->isChecked()||ui->pushButton_44->isChecked()
        ||ui->pushButton_45->isChecked())
    {
        txtEdit->appendPlainText("恋爱：");
        if(ui->pushButton_37->isChecked())
            txtEdit->appendPlainText("期待入室抢劫的恋爱 ");
        if(ui->pushButton_38->isChecked())
            txtEdit->appendPlainText("喜欢温柔的人 ");
        if(ui->pushButton_39->isChecked())
            txtEdit->appendPlainText("喜欢有趣的人 ");
        if(ui->pushButton_40->isChecked())
            txtEdit->appendPlainText("有点恋爱脑 ");
        if(ui->pushButton_41->isChecked())
            txtEdit->appendPlainText("爱情宁缺毋滥 ");
        if(ui->pushButton_42->isChecked())
            txtEdit->appendPlainText("纯爱战神 ");
        if(ui->pushButton_43->isChecked())
            txtEdit->appendPlainText("声控 ");
        if(ui->pushButton_44->isChecked())
            txtEdit->appendPlainText("颜控 ");
        if(ui->pushButton_45->isChecked())
            txtEdit->appendPlainText("智性恋 ");
        txtEdit->appendPlainText("");
    }
    if(ui->pushButton_46->isChecked()||ui->pushButton_47->isChecked()||ui->pushButton_48->isChecked()||ui->pushButton_49->isChecked()
        ||ui->pushButton_50->isChecked()||ui->pushButton_51->isChecked()||ui->pushButton_52->isChecked()||ui->pushButton_53->isChecked()
        ||ui->pushButton_54->isChecked())
    {
        txtEdit->appendPlainText("书/影/音：");
        if(ui->pushButton_46->isChecked())
            txtEdit->appendPlainText("喜欢国风音乐 ");
        if(ui->pushButton_47->isChecked())
            txtEdit->appendPlainText("喜欢欧美音乐 ");
        if(ui->pushButton_48->isChecked())
            txtEdit->appendPlainText("爱看喜剧 ");
        if(ui->pushButton_49->isChecked())
            txtEdit->appendPlainText("二次元 ");
        if(ui->pushButton_50->isChecked())
            txtEdit->appendPlainText("一起听live ");
        if(ui->pushButton_51->isChecked())
            txtEdit->appendPlainText("会点乐器 ");
        if(ui->pushButton_52->isChecked())
            txtEdit->appendPlainText("喜欢看书 ");
        if(ui->pushButton_53->isChecked())
            txtEdit->appendPlainText("爱唱歌 ");
        if(ui->pushButton_54->isChecked())
            txtEdit->appendPlainText("追番达人 ");
        txtEdit->appendPlainText("");
    }
    if(ui->pushButton_55->isChecked()||ui->pushButton_56->isChecked()||ui->pushButton_57->isChecked()||ui->pushButton_58->isChecked()
        ||ui->pushButton_59->isChecked()||ui->pushButton_60->isChecked()||ui->pushButton_61->isChecked()||ui->pushButton_62->isChecked()
        ||ui->pushButton_63->isChecked())
    {
        txtEdit->appendPlainText("美食：");
        if(ui->pushButton_55->isChecked())
            txtEdit->appendPlainText("咖啡品鉴师 ");
        if(ui->pushButton_56->isChecked())
            txtEdit->appendPlainText("厨艺不错 ");
        if(ui->pushButton_57->isChecked())
            txtEdit->appendPlainText("我爱火锅 ");
        if(ui->pushButton_58->isChecked())
            txtEdit->appendPlainText("无辣不欢 ");
        if(ui->pushButton_59->isChecked())
            txtEdit->appendPlainText("无肉不欢 ");
        if(ui->pushButton_60->isChecked())
            txtEdit->appendPlainText("奶茶控 ");
        if(ui->pushButton_61->isChecked())
            txtEdit->appendPlainText("甜食控 ");
        if(ui->pushButton_62->isChecked())
            txtEdit->appendPlainText("探店达人 ");
        if(ui->pushButton_63->isChecked())
            txtEdit->appendPlainText("素食主义 ");
        txtEdit->appendPlainText("");
    }
}

void tagswindow::on_toolButton_recommend_clicked()
{
    ui->stackedWidget->setCurrentIndex(1);
}


void tagswindow::on_toolButton_personality_clicked()
{
    ui->stackedWidget->setCurrentIndex(2);
}


void tagswindow::on_toolButton_sports_clicked()
{
    ui->stackedWidget->setCurrentIndex(3);
}


void tagswindow::on_toolButton_game_clicked()
{
    ui->stackedWidget->setCurrentIndex(4);
}


void tagswindow::on_toolButton_love_clicked()
{
    ui->stackedWidget->setCurrentIndex(5);
}


void tagswindow::on_toolButton_entertainment_clicked()
{
    ui->stackedWidget->setCurrentIndex(6);
}


void tagswindow::on_toolButton_food_clicked()
{
    ui->stackedWidget->setCurrentIndex(7);
}


void tagswindow::on_pushButton_64_clicked()
{
    save();
    output();
    this->close();
}

