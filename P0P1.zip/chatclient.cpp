#include "chatclient.h"
#include "ui_chatclient.h"
#include "infowindow.h"
#include "mainwindow.h"
#include <QDateTime>
#include <QJsonObject>
#include <QJsonDocument>

ChatClient::ChatClient(QString user_name,QString other_user_name,QString usr_name,QString other_name,QTcpSocket *socket_,QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::ChatClient),socket(socket_)
{
    ui->setupUi(this);
    client_user_name=user_name;
    opp_user_name=other_user_name;
    client_name=usr_name;
    opp_name=other_name;
    ui->name->setText(opp_name);
    connect(socket, &QTcpSocket::readyRead, this, &ChatClient::readMessage);
    connect(socket, QOverload<QAbstractSocket::SocketError>::of(&QAbstractSocket::errorOccurred),
            this, &ChatClient::displayError);
    //connect(ui->connectButton, &QPushButton::clicked, this, &ChatClient::connectToServer);
    connect(ui->sendButton, &QPushButton::clicked, this, &ChatClient::sendMessage);
    // QString ipAddress="10.129.210.11";//192.168.3.133
    // quint16 port=1234;
    // socket->connectToHost(ipAddress,port);
}

ChatClient::~ChatClient()
{
    delete ui;
}

QString ChatClient::client_Send_Friend_Msg_ToJson(const QString &client_id, const QString &opp_id, const QString &text)
{
    // 创建JSON对象
    QJsonObject jsonObj;
    jsonObj["client_id"] = client_id;
    jsonObj["mode"] = "friend";
    jsonObj["do"] = "send";
    jsonObj["opp_id"] = opp_id;
    jsonObj["text"] = text;

    // 将JSON对象转换为JSON文档
    QJsonDocument jsonDoc(jsonObj);

    // 将JSON文档转换为QString（JSON字符串）
    QString jsonString = jsonDoc.toJson(QJsonDocument::Compact);

    return jsonString;
}

QString ChatClient::client_Send_Info_Msg_ToJson(const QString &client_id, const QString &text)
{
    // 创建JSON对象
    QJsonObject jsonObj;
    jsonObj["client_id"] = client_id;
    jsonObj["mode"] = "information";
    jsonObj["text"] = text;

    // 将JSON对象转换为JSON文档
    QJsonDocument jsonDoc(jsonObj);

    // 将JSON文档转换为QString（JSON字符串）
    QString jsonString = jsonDoc.toJson(QJsonDocument::Compact);

    return jsonString;
}

QJsonObject ChatClient::jsonToData(const QString &jsonString)
{
    // 将QString转换为QByteArray
    QByteArray jsonData = jsonString.toUtf8();

    // 将QByteArray解析为JSON文档
    QJsonDocument jsonDoc = QJsonDocument::fromJson(jsonData);

    // 将JSON文档转换为JSON对象
    QJsonObject jsonObj = jsonDoc.object();

    return jsonObj;
}

// void ChatClient::connectToServer()
// {
//     QString ipAddress = ui->ipAddressLineEdit->text();
//     quint16 port = ui->portLineEdit->text().toUShort();
//     socket->connectToHost(ipAddress, port);
// }

void ChatClient::readMessage()
{
    QString text=socket->readAll();
    QJsonObject json=jsonToData(text);
    QString client_id=json["client_id"].toString();
    QString opp_id=json["opp_id"].toString();
    QString message=json["text"].toString();
    if(client_id==client_user_name)
        ui->log->append(message);
    if(client_id==opp_user_name)
        ui->log->append(message);
}

void ChatClient::sendMessage()
{
    QDateTime dateTime=QDateTime::currentDateTime();
    QString date=dateTime.date().toString("yyyy-M-d");
    QString time=dateTime.time().toString("h:mm:ss");
    QString message = ui->messageEdit->toPlainText();
    QString text=date+" "+time+"\n"+client_name+": " + message;
    //client_user_name
    //opp_user_name
    QString jsonString=client_Send_Friend_Msg_ToJson(client_user_name,opp_user_name,text);
    socket->write(jsonString.toUtf8());//toUtf8()
    //socket->write((opp_name+": "+message).toUtf8());
    //socket->write(message.toUtf8());
    //ui->log->append(text);
    ui->messageEdit->clear();
}

void ChatClient::displayError(QAbstractSocket::SocketError socketError)
{
    Q_UNUSED(socketError)
    ui->log->append("Error: " + socket->errorString());
}

void ChatClient::on_toolButton_clicked()
{
    infoWindow *info=new infoWindow(opp_name);
    info->setWindowFlag(Qt::MSWindowsFixedSizeDialogHint);
    info->show();
}

