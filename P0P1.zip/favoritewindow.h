#ifndef FAVORITEWINDOW_H
#define FAVORITEWINDOW_H

#include <QWidget>

namespace Ui {
class FavoriteWindow;
}

class FavoriteWindow : public QWidget
{
    Q_OBJECT

public:
    explicit FavoriteWindow(QWidget *parent = nullptr);
    ~FavoriteWindow();

private:
    Ui::FavoriteWindow *ui;
};

#endif // FAVORITEWINDOW_H
