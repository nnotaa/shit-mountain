#include "mainwindow.h"
#include "loginwindow.h"

#include <QApplication>
#include <QLocale>
#include <QTranslator>
#include <QString>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    QTranslator translator;
    const QStringList uiLanguages = QLocale::system().uiLanguages();
    for (const QString &locale : uiLanguages) {
        const QString baseName = "P0P1_" + QLocale(locale).name();
        if (translator.load(":/i18n/" + baseName)) {
            a.installTranslator(&translator);
            break;
        }
    }
    MainWindow w;
    LoginWindow lw;
    if(w.readAuthTokenFromFile()){
        w.show();
    }
    else{
        lw.show();
        //w.show();
    }
    return a.exec();
}
