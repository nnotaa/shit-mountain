#ifndef LOGINWINDOW_H
#define LOGINWINDOW_H

#include <QMainWindow>
#include <QNetworkAccessManager>
#include <QNetworkReply>
#include <QNetworkRequest>
#include <QUrlQuery>

QT_BEGIN_NAMESPACE
namespace Ui { class LoginWindow; }
QT_END_NAMESPACE

class LoginWindow : public QMainWindow
{
    Q_OBJECT

public:
    LoginWindow(QWidget *parent = nullptr);
    ~LoginWindow();

private slots:
    void on_loginButton_clicked();
    void on_sendCaptchaButton_clicked();
    void on_verifyCaptchaButton_clicked();
    void onNetworkReplyFinished(QNetworkReply *reply);
    void handleLoginReply(QNetworkReply *reply);
    void handleSendCaptchaReply(QNetworkReply *reply);
    void handleVerifyCaptchaReply(QNetworkReply *reply);

private:
    Ui::LoginWindow *ui;
    QNetworkAccessManager *networkManager;
    QString authToken; // 保存认证Token
    QString authTokenPath = "authtoken/auth_token.txt";

    void debugOutput(const QString &message);
    bool saveAuthTokenToFile();
};

#endif // LOGINWINDOW_H
