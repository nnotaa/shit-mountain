#ifndef CHATCLIENT_H
#define CHATCLIENT_H

#include <QWidget>
#include <QTcpSocket>
#include <QJsonObject>
#include <QJsonDocument>

namespace Ui {
class ChatClient;
}

class ChatClient : public QWidget
{
    Q_OBJECT

public:
    explicit ChatClient(QString user_name,QString other_user_name,QString usr_name,QString other_name,QTcpSocket *socket_,QWidget *parent = nullptr);
    ~ChatClient();
    QString client_user_name;
    QString opp_user_name;
    QString client_name;
    QString opp_name;
    QString client_Send_Friend_Msg_ToJson(const QString& client_id, const QString& opp_id, const QString& text);
    QString client_Send_Info_Msg_ToJson(const QString& client_id,const QString& text);
    QJsonObject jsonToData(const QString& jsonString);

signals:
    void dataReceived(QString opp_name,QString message);
private slots:
    // void connectToServer();
    void readMessage();
    void sendMessage();
    void displayError(QAbstractSocket::SocketError socketError);

    void on_toolButton_clicked();

private:
    Ui::ChatClient *ui;
    QTcpSocket *socket;
};

#endif // CHATCLIENT_H
