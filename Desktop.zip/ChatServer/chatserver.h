// chatserver.h
#ifndef CHATSERVER_H
#define CHATSERVER_H

#include <QWidget>
#include <QTcpServer>
#include <QTcpSocket>
#include <QJsonObject>
#include <QJsonDocument>
#include <QJsonArray>
#include <QString>
#include <QCoreApplication>
#include <QDir>
#include <QFile>
#include <QDebug>

QT_BEGIN_NAMESPACE
namespace Ui { class ChatServer; }
QT_END_NAMESPACE

class ChatServer : public QWidget
{
    Q_OBJECT

public:
    ChatServer(QWidget *parent = nullptr);
    ~ChatServer();

private slots:
    void newConnection();
    void readMessage();
    void clientDisconnected();
    void sendMessageToClient(const QString &message, const QString &clientName); // 新增

private:
    Ui::ChatServer *ui;
    QTcpServer *server;
    QList<QTcpSocket*> clients;
    void broadcastMessage(const QString &message);
    struct ClientInfo {
        QTcpSocket *socket;
        QString name;
    };

    QList<ClientInfo> clientInfos; // 新增
    QTcpSocket* findClientByName(const QString &name); // 新增
    void processMessage(const QString &message);
    QJsonObject jsonToData(const QString& jsonString);
    QString server_Send_p0p1_Msg_ToJson(const QString& p0p1_host, const QJsonArray& text);
    QString server_Send_Friend_Msg_ToJson(const QString& opp_id, const QString& text);
    void appendJsonObjectToFile(const QJsonObject& jsonObject, const QString& p0p1_host);
    QList<QJsonObject> readJsonObjectsFromFile(const QString& p0p1_host);

};

#endif // CHATSERVER_H
