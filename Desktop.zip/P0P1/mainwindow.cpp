#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "p0p1_client.h"
#include "tagswindow.h"
#include "treeholewindow.h"
#include "chatclient.h"
#include "favoritewindow.h"
#include <QFileDialog>
#include <QColorDialog>
#include <QFontDialog>
#include <QProgressDialog>
#include <QElapsedTimer>
#include <QInputDialog>
#include <QFileDialog>
#include <QSaveFile>
#include <QException>
#include <QMessageBox>
#include <QTextBlock>
#include <QUrl>
#include <QNetworkAccessManager>
#include <QNetworkRequest>
#include <QNetworkReply>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QJsonValue>
#include <QByteArray>
#include <QString>
#include <QDebug>
#include <QDateTime>
#include <QScrollBar>

QString MainWindow::message_str = "";

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow),socket(new QTcpSocket(this))
{
    ui->setupUi(this);
    //message_str="";
    ui->btn_name->setStyleSheet("text-align: left;");
    ui->btn_changetags->setStyleSheet("text-align: left;");
    ui->comboBox_age->setCurrentText("18");
    ui->comboBox_height->setCurrentText("170-175");
    openFile();
    usr_name=ui->btn_name->text();
    //socket->write(user_name.toUtf8());
    QString ipAddress="192.168.3.133";//10.6.220.60
    quint16 port=1234;
    socket->connectToHost(ipAddress,port);
    printHoleInformation();
}

MainWindow::~MainWindow()
{
    saveFile();
    delete ui;
}

void MainWindow::openFile()
{
    QDir currentDir=QDir::current();
    QString dirPath="current";
    if(!currentDir.exists(dirPath))
    {
        if(!currentDir.mkdir(dirPath))
            return;
    }
    //设置学号
    QFile usernameFile(currentDir.filePath(dirPath+"/username.txt"));
    if(!usernameFile.exists())
        return;
    if(!usernameFile.open(QIODevice::ReadOnly | QIODevice::Text))
        return;
    QTextStream usernametxt(&usernameFile);
    user_name=usernametxt.readAll();
    //设置头像
    QIcon icon(currentDir.filePath(dirPath+"/profile.jpg"));
    //QIcon icon("profile.jpg");
    ui->btn_profile->setIcon(icon);
    //设置昵称
    QFile nameFile(currentDir.filePath(dirPath+"/name.txt"));
    if(!nameFile.exists())
        return;
    if(!nameFile.open(QIODevice::ReadOnly | QIODevice::Text))
        return;
    QTextStream nametxt(&nameFile);
    ui->btn_name->setText(nametxt.readAll());
    //设置性别
    QFile sexFile(currentDir.filePath(dirPath+"/sex.txt"));
    if(!sexFile.exists())
        return;
    if(!sexFile.open(QIODevice::ReadOnly | QIODevice::Text))
        return;
    QTextStream sextxt(&sexFile);
    ui->comboBox_sex->setCurrentText(sextxt.readAll());
    //设置性向
    QFile appetenceFile(currentDir.filePath(dirPath+"/appetence.txt"));
    if(!appetenceFile.exists())
        return;
    if(!appetenceFile.open(QIODevice::ReadOnly | QIODevice::Text))
        return;
    QTextStream appetencetxt(&appetenceFile);
    ui->comboBox_appetence->setCurrentText(appetencetxt.readAll());
    //设置年龄
    QFile ageFile(currentDir.filePath(dirPath+"/age.txt"));
    if(!ageFile.exists())
        return;
    if(!ageFile.open(QIODevice::ReadOnly | QIODevice::Text))
        return;
    QTextStream agetxt(&ageFile);
    ui->comboBox_age->setCurrentText(agetxt.readAll());
    //设置身高
    QFile heightFile(currentDir.filePath(dirPath+"/height.txt"));
    if(!heightFile.exists())
        return;
    if(!heightFile.open(QIODevice::ReadOnly | QIODevice::Text))
        return;
    QTextStream heighttxt(&heightFile);
    ui->comboBox_height->setCurrentText(heighttxt.readAll());
    //设置mbti
    QFile mbtiFile(currentDir.filePath(dirPath+"/mbti.txt"));
    if(!mbtiFile.exists())
        return;
    if(!mbtiFile.open(QIODevice::ReadOnly | QIODevice::Text))
        return;
    QTextStream mbtitxt(&mbtiFile);
    ui->comboBox_mbti->setCurrentText(mbtitxt.readAll());
    //设置星座
    QFile constellationFile(currentDir.filePath(dirPath+"/constellation.txt"));
    if(!constellationFile.exists())
        return;
    if(!constellationFile.open(QIODevice::ReadOnly | QIODevice::Text))
        return;
    QTextStream constellationtxt(&constellationFile);
    ui->comboBox_constellation->setCurrentText(constellationtxt.readAll());
    //设置tag
    QFile tagFile(currentDir.filePath(dirPath+"/tag.txt"));
    if(!tagFile.exists())
        return;
    if(!tagFile.open(QIODevice::ReadOnly | QIODevice::Text))
        return;
    QTextStream tagtxt(&tagFile);
    ui->txt_tags->setPlainText(tagtxt.readAll());
}

void MainWindow::saveFile()
{
    QDir currentDir=QDir::current();
    QString dirPath="current";
    if(!currentDir.exists(dirPath))
    {
        if(!currentDir.mkdir(dirPath))
            return;
    }
    //保存头像
    QIcon icon=ui->btn_profile->icon();
    QPixmap profile=icon.pixmap(icon.actualSize(QSize(160,160)));
    QFile profileFile(currentDir.filePath(dirPath+"/profile.jpg"));
    //QFile profileFile("profile.jpg");
    if(!profileFile.open(QIODevice::WriteOnly))
        return;
    profile.save(&profileFile);
    profileFile.close();
    //保存昵称
    QFile nameFile(currentDir.filePath(dirPath+"/name.txt"));
    if(!nameFile.open(QIODevice::WriteOnly | QIODevice::Text))
        return;
    QTextStream nametxt(&nameFile);
    nametxt<<ui->btn_name->text();
    nameFile.close();
    //保存性别
    QFile sexFile(currentDir.filePath(dirPath+"/sex.txt"));
    if(!sexFile.open(QIODevice::WriteOnly | QIODevice::Text))
        return;
    QTextStream sextxt(&sexFile);
    sextxt<<ui->comboBox_sex->currentText();
    sexFile.close();
    //保存性向
    QFile appetenceFile(currentDir.filePath(dirPath+"/appetence.txt"));
    if(!appetenceFile.open(QIODevice::WriteOnly | QIODevice::Text))
        return;
    QTextStream appetencetxt(&appetenceFile);
    appetencetxt<<ui->comboBox_appetence->currentText();
    appetenceFile.close();
    //保存年龄
    QFile ageFile(currentDir.filePath(dirPath+"/age.txt"));
    if(!ageFile.open(QIODevice::WriteOnly | QIODevice::Text))
        return;
    QTextStream agetxt(&ageFile);
    agetxt<<ui->comboBox_age->currentText();
    ageFile.close();
    //保存身高
    QFile heightFile(currentDir.filePath(dirPath+"/height.txt"));
    if(!heightFile.open(QIODevice::WriteOnly | QIODevice::Text))
        return;
    QTextStream heighttxt(&heightFile);
    heighttxt<<ui->comboBox_height->currentText();
    heightFile.close();
    //保存mbti
    QFile mbtiFile(currentDir.filePath(dirPath+"/mbti.txt"));
    if(!mbtiFile.open(QIODevice::WriteOnly | QIODevice::Text))
        return;
    QTextStream mbtitxt(&mbtiFile);
    mbtitxt<<ui->comboBox_mbti->currentText();
    mbtiFile.close();
    //保存星座
    QFile constellationFile(currentDir.filePath(dirPath+"/constellation.txt"));
    if(!constellationFile.open(QIODevice::WriteOnly | QIODevice::Text))
        return;
    QTextStream constellationtxt(&constellationFile);
    constellationtxt<<ui->comboBox_constellation->currentText();
    constellationFile.close();
    //保存tag
    QFile tagFile(currentDir.filePath(dirPath+"/tag.txt"));
    if(!tagFile.open(QIODevice::WriteOnly | QIODevice::Text))
        return;
    QTextStream tagtxt(&tagFile);
    tagtxt<<ui->txt_tags->toPlainText();
    tagFile.close();
}

void MainWindow::on_btn_name_clicked()
{
    QString dlgTitle="修改用户名";
    QString textLabel="请输入新的用户名";
    QString initInput=ui->btn_name->text();
    QLineEdit::EchoMode echoMode=QLineEdit::Normal;
    bool ok=false;
    QString text=QInputDialog::getText(this,dlgTitle,textLabel,echoMode,initInput,&ok);
    if(ok&&!text.isEmpty())
    {
        ui->btn_name->setText(text);
        usr_name=text;
    }

}


void MainWindow::on_btn_profile_clicked()
{
    QString initPath=QDir::homePath();
    QString fileName = QFileDialog::getOpenFileName(this,"选择图片",initPath,"Images (*.png *.jpg *.bmp)");
    if(!fileName.isEmpty())
    {
        QPixmap pixmap(fileName);
        if(!pixmap.isNull())
        {
            QIcon icon(pixmap);
            ui->btn_profile->setIcon(icon);
        }
    }
}

void MainWindow::on_btn_changetags_clicked()
{
    QPlainTextEdit *txtEdit=ui->txt_tags;
    tagswindow *window=new tagswindow(txtEdit);
    window->setWindowFlag(Qt::MSWindowsFixedSizeDialogHint);
    window->show();
    //window->output();
}

void MainWindow::on_toolButton_2_clicked()
{
    P0P1_Client *client=new P0P1_Client(user_name,"2300013110",usr_name,"nnotaa",socket);
    client->setWindowFlag(Qt::MSWindowsFixedSizeDialogHint);
    client->show();

}

void MainWindow::on_toolButton_3_clicked()
{
    P0P1_Client *client=new P0P1_Client(user_name,"2300013111",usr_name,"Sun.",socket);
    client->setWindowFlag(Qt::MSWindowsFixedSizeDialogHint);
    client->show();
}


void MainWindow::on_toolButton_4_clicked()
{
    P0P1_Client *client=new P0P1_Client(user_name,"2300013112",usr_name,"takumi",socket);
    client->setWindowFlag(Qt::MSWindowsFixedSizeDialogHint);
    client->show();
}


void MainWindow::on_toolButton_5_clicked()
{
    P0P1_Client *client=new P0P1_Client(user_name,"5201314",usr_name,"胡桃",socket);
    client->setWindowFlag(Qt::MSWindowsFixedSizeDialogHint);
    client->show();
}


void MainWindow::on_toolButton_6_clicked()
{
    P0P1_Client *client=new P0P1_Client(user_name,"2300013113",usr_name,"Re.id",socket);
    client->setWindowFlag(Qt::MSWindowsFixedSizeDialogHint);
    client->show();
}


void MainWindow::on_toolButton_7_clicked()
{
    P0P1_Client *client=new P0P1_Client(user_name,"2300013114",usr_name,"kaixa",socket);
    client->setWindowFlag(Qt::MSWindowsFixedSizeDialogHint);
    client->show();
}


void MainWindow::on_toolButton_8_clicked()
{
    P0P1_Client *client=new P0P1_Client(user_name,"2300013115",usr_name,"biubiu~~~",socket);
    client->setWindowFlag(Qt::MSWindowsFixedSizeDialogHint);
    client->show();
}


void MainWindow::on_toolButton_9_clicked()
{
    P0P1_Client *client=new P0P1_Client(user_name,"99999999",usr_name,"流萤",socket);
    client->setWindowFlag(Qt::MSWindowsFixedSizeDialogHint);
    client->show();
}


void MainWindow::on_toolButton_12_clicked()
{
    ChatClient *client=new ChatClient(user_name,"99999999",usr_name,"流萤",socket);
    client->setWindowFlag(Qt::MSWindowsFixedSizeDialogHint);
    client->show();
}


void MainWindow::on_toolButton_11_clicked()
{
    ChatClient *client=new ChatClient(user_name,"2300013110",usr_name,"nnotaa",socket);
    client->setWindowFlag(Qt::MSWindowsFixedSizeDialogHint);
    client->show();
}


void MainWindow::on_toolButton_10_clicked()
{
    ChatClient *client=new ChatClient(user_name,"5201314",usr_name,"胡桃",socket);
    client->setWindowFlag(Qt::MSWindowsFixedSizeDialogHint);
    client->show();
}

bool MainWindow::readAuthTokenFromFile() {
    QDir currentDir=QDir::current();
    QString dirPath="authtoken";
    if(!currentDir.exists(dirPath))
    {
        if(!currentDir.mkdir(dirPath))
            return false;
    }
    QFile file(authTokenPath);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        return false;
    }

    authToken = file.readAll().trimmed();
    file.close();

    return !authToken.isEmpty();
}

HoleInformation MainWindow::responseDatatoHoleInformation(const QByteArray &responseData) {
    // 将QByteArray转换为QJsonDocument
    QJsonDocument jsonDoc = QJsonDocument::fromJson(responseData);

    // 确保JSON文档是对象类型
    if (!jsonDoc.isObject()) {
        qWarning() << "Invalid JSON document";
        return HoleInformation();
    }

    // 获取JSON对象
    QJsonObject jsonObj = jsonDoc.object();
    QJsonObject dataObj = jsonObj["data"].toObject();

    // 提取所需字段
    HoleInformation data;
    data.pid = QString::number(dataObj["pid"].toInt());
    data.text = dataObj["text"].toString();
    data.reply = dataObj["reply"].toInt();
    data.likenum = dataObj["likenum"].toInt();

    QString timestampStr = QString::number(dataObj["timestamp"].toInt());
    qint64 timestamp = timestampStr.toLongLong();
    // 使用 QDateTime 从时间戳创建日期时间对象
    QDateTime dateTime;
    dateTime.setSecsSinceEpoch(timestamp);
    // 将日期时间对象格式化为字符串
    data.time = dateTime.toString("yyyy-MM-dd HH:mm:ss");
    return data;
}

QList<HoleInformation> MainWindow::responseDatatoHolesInformation(const QByteArray &responseData) {
    // 将QByteArray转换为QJsonDocument
    QJsonDocument jsonDoc = QJsonDocument::fromJson(responseData);

    // 确保JSON文档是对象类型
    if (!jsonDoc.isObject()) {
        qWarning() << "Invalid JSON document";
        return {};
    }

    // 获取JSON对象
    QJsonObject jsonObj = jsonDoc.object();
    QJsonObject dataObj0 = jsonObj["data"].toObject();
    QJsonArray dataArr = dataObj0["data"].toArray();
    QList<HoleInformation> ans;

    for(int i=0;i<dataArr.size();i++)
    {
        QJsonObject dataObj = dataArr[i].toObject();
        // 提取所需字段
        HoleInformation data;
        data.pid = QString::number(dataObj["pid"].toInt());
        data.text = dataObj["text"].toString();
        data.reply = dataObj["reply"].toInt();
        data.likenum = dataObj["likenum"].toInt();

        QString timestampStr = QString::number(dataObj["timestamp"].toInt());
        qint64 timestamp = timestampStr.toLongLong();
        // 使用 QDateTime 从时间戳创建日期时间对象
        QDateTime dateTime;
        dateTime.setSecsSinceEpoch(timestamp);
        // 将日期时间对象格式化为字符串
        data.time = dateTime.toString("yyyy-MM-dd HH:mm:ss");
        ans.append(data);
    }

    return ans;
}

QList<CommentInformation> MainWindow::responseDatatoCommentInformation(const QByteArray &responseData) {
    // 将QByteArray转换为QJsonDocument
    QJsonDocument jsonDoc = QJsonDocument::fromJson(responseData);

    // 确保JSON文档是对象类型
    if (!jsonDoc.isObject()) {
        qWarning() << "Invalid JSON document";
        return {};
    }

    // 获取JSON对象
    QJsonObject jsonObj = jsonDoc.object();
    QJsonObject dataObj0 = jsonObj["data"].toObject();
    QJsonArray dataArr = dataObj0["data"].toArray();
    QList<CommentInformation> ans;

    for(int i=0;i<dataArr.size();i++)
    {
        QJsonObject dataObj = dataArr[i].toObject();
        CommentInformation data;
        data.cid = QString::number(dataObj["cid"].toInt());
        data.pid = QString::number(dataObj["pid"].toInt());
        data.text = dataObj["text"].toString();
        data.name = dataObj["name"].toString();
        if(!dataObj["tag"].isNull()){
            data.tag = dataObj["tag"].toString();
        }
        if(!dataObj["comment_id"].isNull()){
            data.comment_id = QString::number(dataObj["comment_id"].toInt());
        }
        QString timestampStr = QString::number(dataObj["timestamp"].toInt());;
        qint64 timestamp = timestampStr.toLongLong();
        // 使用 QDateTime 从时间戳创建日期时间对象
        QDateTime dateTime;
        dateTime.setSecsSinceEpoch(timestamp);
        // 将日期时间对象格式化为字符串
        data.time = dateTime.toString("yyyy-MM-dd HH:mm:ss");
        ans.append(data);
    }
    return ans;
}

/*
int MainWindow::responseDatatoNewestHolenum(const QByteArray &responseData) {
    // 将QByteArray转换为QJsonDocument
    QJsonDocument jsonDoc = QJsonDocument::fromJson(responseData);

    // 确保JSON文档是对象类型
    if (!jsonDoc.isObject()) {
        qWarning() << "Invalid JSON document";
        return 0;
    }

    // 获取JSON对象
    QJsonObject jsonObj = jsonDoc.object();
    QJsonObject dataObj = jsonObj["data"].toObject();
    QJsonValue q = dataObj["data"];
    QJsonArray aa =q.toArray();
    QJsonObject firstDataObj = aa.at(0).toObject();
    // 提取所需字段
    return firstDataObj["pid"].toInt();
}
*/


HoleInformation MainWindow::getHoleReplyFromTreehole(const QString& hole_id) {
    HoleInformation ret;
    // 创建一个QNetworkAccessManager对象
    QNetworkAccessManager *manager = new QNetworkAccessManager();

    // 创建一个请求对象，并设置要请求的URL
    QNetworkRequest request;
    request.setUrl(QUrl("https://treehole.pku.edu.cn/api/pku/"+hole_id));//https://treehole.pku.edu.cn/api/pku_image/6314183

    // 添加Token身份验证信息
    request.setRawHeader("Authorization", QByteArray("Bearer ") + authToken.toUtf8());

    // 发送GET请求，并连接信号槽处理响应
    QNetworkReply *reply = manager->get(request);

    // 创建一个局部事件循环
    QEventLoop eventLoop;

    // 读取响应数据
    QObject::connect(reply, &QNetworkReply::finished, [&]() {
        if (reply->error() == QNetworkReply::NoError) {
            // 输出到控制台
            QByteArray responseData = reply->readAll();
            //qDebug() << responseData;
            ret=responseDatatoHoleInformation(responseData);
            //ui->plainTextEdit->appendPlainText();
        } else {
            // 输出错误信息
            qDebug() << "Error: " << reply->errorString();
        }

        // 释放资源
        reply->deleteLater();
        manager->deleteLater();
        // 退出事件循环
        eventLoop.quit();
    });

    // 进入局部事件循环，直到请求完成
    eventLoop.exec();

    return ret;
}

QList<HoleInformation> MainWindow::getHoles(int page,int limit) {
    QList<HoleInformation> ret={};
    // 创建一个QNetworkAccessManager对象
    QNetworkAccessManager *manager = new QNetworkAccessManager();

    // 创建一个请求对象，并设置要请求的URL
    QNetworkRequest request;
    if(ui->pushButton_4->isChecked())
        request.setUrl(QUrl("https://treehole.pku.edu.cn/api/follow_v2?page="+QString::number(page)+"&limit="+QString::number(limit)));//https://treehole.pku.edu.cn/api/pku_image/6314183
    else
        request.setUrl(QUrl("https://treehole.pku.edu.cn/api/pku_hole?page="+QString::number(page)+"&limit="+QString::number(limit)));//https://treehole.pku.edu.cn/api/pku_image/6314183
    // 添加Token身份验证信息
    request.setRawHeader("Authorization", QByteArray("Bearer ") + authToken.toUtf8());

    // 发送GET请求，并连接信号槽处理响应
    QNetworkReply *reply = manager->get(request);

    // 创建一个局部事件循环
    QEventLoop eventLoop;

    // 读取响应数据
    QObject::connect(reply, &QNetworkReply::finished, [&]() {
        if (reply->error() == QNetworkReply::NoError) {
            // 输出到控制台
            QByteArray responseData = reply->readAll();
            qDebug() << responseData;
            ret=responseDatatoHolesInformation(responseData);
            //ui->plainTextEdit->appendPlainText();
        } else {
            // 输出错误信息
            qDebug() << "Error: " << reply->errorString();
        }

        // 释放资源
        reply->deleteLater();
        manager->deleteLater();
        // 退出事件循环
        eventLoop.quit();
    });

    // 进入局部事件循环，直到请求完成
    eventLoop.exec();

    return ret;
}

QList<CommentInformation> MainWindow::getCommentReplyFromTreehole(const QString& hole_id) {
    // 创建一个QNetworkAccessManager对象
    QNetworkAccessManager *manager = new QNetworkAccessManager();
    QList<CommentInformation> ret = {};
    // 创建一个请求对象，并设置要请求的URL
    QNetworkRequest request;
    request.setUrl(QUrl("https://treehole.pku.edu.cn/api/pku_comment_v3/"+hole_id));//api/pku_comment_v3/6314721?limit=2

    // 添加Token身份验证信息
    request.setRawHeader("Authorization", QByteArray("Bearer ") + authToken.toUtf8());

    // 发送GET请求，并连接信号槽处理响应
    QNetworkReply *reply = manager->get(request);

    // 创建一个局部事件循环
    QEventLoop eventLoop;

    QObject::connect(reply, &QNetworkReply::finished, [&]() {
        if (reply->error() == QNetworkReply::NoError) {
            // 读取响应数据
            QByteArray responseData = reply->readAll();
            // 输出到控制台
            //qDebug() << responseData;
            ret = responseDatatoCommentInformation(responseData);
        } else {
            // 输出错误信息
            qDebug() << "Error: " << reply->errorString();
        }

        // 释放资源
        reply->deleteLater();
        manager->deleteLater();

        // 退出事件循环
        eventLoop.quit();
    });

    // 进入局部事件循环，直到请求完成
    eventLoop.exec();
    return ret;
}


void MainWindow::printHoleInformation(){
    ui->plainTextEdit->clear();
    ui->plainTextEdit->appendPlainText("##########");
    int page = ui->lineEdit_4->text().toInt();
    int limit = 10;
    int like_limit = ui->lineEdit_3->text().toInt();
    int reply_limit = ui->lineEdit_2->text().toInt();
    QList<HoleInformation> newest_holes = getHoles(page,limit);
    for(int i=0;i<newest_holes.size();i++)
    {
        HoleInformation tmp = newest_holes[i];
        if(tmp.likenum<like_limit || tmp.reply<reply_limit){
            continue;
        }
        ui->plainTextEdit->appendPlainText("#"+tmp.pid+"   "+tmp.time);
        ui->plainTextEdit->appendPlainText(tmp.text);
        ui->plainTextEdit->appendPlainText("⭐:"+QString::number(tmp.likenum)+"  ✉:"+QString::number(tmp.reply));
        //ui->plainTextEdit->appendPlainText("");
    }
    ui->plainTextEdit->verticalScrollBar()->setValue(0);
    return;
}

void MainWindow::on_pushButton_clicked()
{
    QString hole_id = ui->lineEdit->text();
    HoleInformation tmp = getHoleReplyFromTreehole(hole_id);
    QList<CommentInformation> tmp1 = getCommentReplyFromTreehole(hole_id);
    QString hole_cont="#"+tmp.pid+"   "+tmp.time+"\n"+tmp.text+"\n⭐:"+QString::number(tmp.likenum)+"  ✉:"+QString::number(tmp.reply)+"\n";

    QString hole_comment;

    for(int i=0;i<tmp1.size();i++){
        hole_comment+="   #"+tmp1[i].cid+"   "+tmp1[i].time+"\n   "+tmp1[i].name+": "+tmp1[i].text+"\n";
    }
    TreeholeWindow *tw=new TreeholeWindow(hole_id,hole_cont+hole_comment);
    tw->setWindowFlag(Qt::MSWindowsFixedSizeDialogHint);
    tw->show();
    //ui->plainTextEdit->appendPlainText(tmp.pid+" "+tmp.time);
    //ui->plainTextEdit->appendPlainText(tmp.text);
    //getCommentReplyFromTreehole(hole_id);
}


void MainWindow::on_pushButton_3_clicked()
{
    ui->lineEdit_4->setText("1");
    printHoleInformation();
}

void MainWindow::on_lastpage_clicked()
{
    int page = ui->lineEdit_4->text().toInt();
    if(page<=1){
        ui->lineEdit_4->setText("1");
        return;
    }
    ui->lineEdit_4->setText(QString::number(page-1));
    printHoleInformation();
    return;
}


void MainWindow::on_nextpage_clicked()
{
    int page = ui->lineEdit_4->text().toInt();
    page+=1;
    if(page<1){
        ui->lineEdit_4->setText("1");
    }
    ui->lineEdit_4->setText(QString::number(page));
    printHoleInformation();
    return;
}


void MainWindow::on_lineEdit_4_editingFinished()
{
    printHoleInformation();
    return;
}


void MainWindow::on_lineEdit_4_returnPressed()
{
    printHoleInformation();
    return;
}

