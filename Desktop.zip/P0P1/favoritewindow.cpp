#include "favoritewindow.h"
#include "ui_favoritewindow.h"

FavoriteWindow::FavoriteWindow(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::FavoriteWindow)
{
    ui->setupUi(this);
}

FavoriteWindow::~FavoriteWindow()
{
    delete ui;
}
