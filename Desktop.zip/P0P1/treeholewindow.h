#ifndef TREEHOLEWINDOW_H
#define TREEHOLEWINDOW_H

#include <QWidget>

namespace Ui {
class TreeholeWindow;
}

class TreeholeWindow : public QWidget
{
    Q_OBJECT

public:
    explicit TreeholeWindow(QString hole_index,QString hole_cont,QWidget *parent = nullptr);
    ~TreeholeWindow();
    QString hole_id;
    QString hole_content;

private slots:
    void on_plainTextEdit_updateRequest(const QRect &rect, int dy);

private:
    Ui::TreeholeWindow *ui;
};

#endif // TREEHOLEWINDOW_H
