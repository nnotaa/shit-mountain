#include "infowindow.h"
#include "ui_infowindow.h"

infoWindow::infoWindow(QString name_,QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::infoWindow)
{
    ui->setupUi(this);
    name=name_;
    ui->btn_name->setText(name);
    if(name=="nnotaa")
    {
        ui->btn_profile->setIcon(QIcon(":/icons/freind/nnotaa.jpg"));
        ui->lineEdit_sex->setText("男");
        ui->lineEdit_appetence->setText("女");
        ui->lineEdit_age->setText("19");
        ui->lineEdit_height->setText("180-185");
    }
    if(name=="胡桃")
    {
        ui->btn_profile->setIcon(QIcon(":/icons/freind/hutao1.jpg"));
        ui->lineEdit_sex->setText("女");
        ui->lineEdit_appetence->setText("男");
        ui->lineEdit_age->setText("16");
        ui->lineEdit_height->setText("160-165");
    }
    if(name=="Sun")
    {
        ui->btn_profile->setIcon(QIcon(":/icons/freind/Sun..jpg"));
        ui->lineEdit_sex->setText("女");
        ui->lineEdit_appetence->setText("男");
        ui->lineEdit_age->setText("18");
        ui->lineEdit_height->setText("160-165");
    }
    //ui->btn_profile->setIcon(QIcon(":/icons/freind/hutao.jpg"));
}

infoWindow::~infoWindow()
{
    delete ui;
}
