#include "loginwindow.h"
#include "ui_loginwindow.h"
#include "mainwindow.h"

#include <QJsonDocument>
#include <QJsonObject>
#include <QMessageBox>
#include <QCoreApplication>
#include <QNetworkAccessManager>
#include <QNetworkRequest>
#include <QNetworkReply>
#include <QFile>
#include <QDir>
#include <QDebug>

LoginWindow::LoginWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::LoginWindow)
    , networkManager(new QNetworkAccessManager(this))
{
    ui->setupUi(this);
    // 确保按钮点击事件只连接一次
    // connect(ui->loginButton, &QPushButton::clicked, this, &LoginWindow::on_loginButton_clicked);
    // connect(ui->sendCaptchaButton, &QPushButton::clicked, this, &LoginWindow::on_sendCaptchaButton_clicked);
    // connect(ui->verifyCaptchaButton, &QPushButton::clicked, this, &LoginWindow::on_verifyCaptchaButton_clicked);
    connect(networkManager, &QNetworkAccessManager::finished, this, &LoginWindow::onNetworkReplyFinished);
}

LoginWindow::~LoginWindow()
{
    delete ui;
}

void LoginWindow::debugOutput(const QString &message)
{
    qDebug() << message;
    ui->statusLabel->setText(message);
}

bool LoginWindow::saveAuthTokenToFile() {
    QDir currentDir=QDir::current();
    QString dirPath="authtoken";
    if(!currentDir.exists(dirPath))
    {
        if(!currentDir.mkdir(dirPath))
            return false;
    }
    QFile file(authTokenPath);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        return false;
    }

    file.write(authToken.toUtf8());
    file.close();

    return true;
}

void LoginWindow::on_loginButton_clicked()
{
    // static bool loginButtonClicked = false;
    // if (loginButtonClicked) return;
    // loginButtonClicked = true;
    debugOutput("Login button clicked");

    QString username = ui->usernameLineEdit->text();
    QString password = ui->passwordLineEdit->text();
    QString uid = username; // 将 uid 设置为与 username 相同

    debugOutput("Logging in with user: " + username + " and password: " + password);

    QUrl url("https://treehole.pku.edu.cn/api/login");
    QNetworkRequest request(url);

    QJsonObject json;
    json["username"] = username;
    json["password"] = password;
    json["uid"] = uid; // 添加 uid 字段
    QJsonDocument jsonDoc(json);
    QByteArray jsonData = jsonDoc.toJson(QJsonDocument::Compact);

    debugOutput("Login request payload: " + QString(jsonData));

    request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");
    request.setRawHeader("User-Agent", "Mozilla/5.0");
    networkManager->post(request, jsonData);
}

void LoginWindow::on_sendCaptchaButton_clicked()
{
    // static bool sendCaptchaButtonClicked = false;
    // if (sendCaptchaButtonClicked) return;
    // sendCaptchaButtonClicked = true;

    debugOutput("Send Captcha button clicked");

    // 防止重复点击
    ui->sendCaptchaButton->setEnabled(false);

    QString username = ui->usernameLineEdit->text();
    debugOutput("Sending captcha for user: " + username);

    QUrl url("https://treehole.pku.edu.cn/api/jwt_send_msg");
    QNetworkRequest request(url);

    QJsonObject json;
    json["username"] = username;
    QJsonDocument jsonDoc(json);
    QByteArray jsonData = jsonDoc.toJson(QJsonDocument::Compact);

    debugOutput("Send captcha request payload: " + QString(jsonData));

    request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");
    request.setRawHeader("User-Agent", "Mozilla/5.0");
    request.setRawHeader("Authorization", "Bearer " + authToken.toUtf8()); // 使用认证Token
    networkManager->post(request, jsonData);
}

void LoginWindow::on_verifyCaptchaButton_clicked()
{
    // static bool verifyCaptchaButtonClicked = false;
    // if (verifyCaptchaButtonClicked) return;
    // verifyCaptchaButtonClicked = true;

    debugOutput("Verify Captcha button clicked");

    QString username = ui->usernameLineEdit->text();
    QString captcha = ui->captchaLineEdit->text();
    debugOutput("Verifying captcha for user: " + username);

    QUrl url("https://treehole.pku.edu.cn/api/jwt_msg_verify");
    QNetworkRequest request(url);

    QJsonObject json;
    json["username"] = username;
    json["valid_code"] = captcha;
    QJsonDocument jsonDoc(json);
    QByteArray jsonData = jsonDoc.toJson(QJsonDocument::Compact);
    // debugOutput(jsonData);
    // debugOutput(jsonData);
    // debugOutput(jsonData);

    debugOutput("Verify captcha request payload: " + QString(jsonData));

    request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");
    request.setRawHeader("User-Agent", "Mozilla/5.0");
    request.setRawHeader("Authorization", "Bearer " + authToken.toUtf8()); // 使用认证Token
    networkManager->post(request, jsonData);
}

void LoginWindow::onNetworkReplyFinished(QNetworkReply *reply)
{
    debugOutput("Network reply finished for URL: " + reply->url().toString());

    QString url = reply->url().toString();

    if (url.contains("login")) {
        handleLoginReply(reply);
    } else if (url.contains("jwt_send_msg")) {
        handleSendCaptchaReply(reply);
    } else if (url.contains("jwt_msg_verify")) {
        handleVerifyCaptchaReply(reply);
    }
    reply->deleteLater();
}

void LoginWindow::handleLoginReply(QNetworkReply *reply)
{
    // static bool loginReplyHandled = false;
    // if (loginReplyHandled) return;
    // loginReplyHandled = true;

    debugOutput("Handling login reply");

    if (reply->error() == QNetworkReply::NoError) {
        QByteArray responseData = reply->readAll();
        debugOutput("Login response: " + QString(responseData));

        QJsonDocument jsonDoc = QJsonDocument::fromJson(responseData);
        QJsonObject jsonObj = jsonDoc.object();
        QJsonObject dataObj = jsonObj["data"].toObject();
        authToken = dataObj["jwt"].toString(); // 获取 jwt 字段
        saveAuthTokenToFile();
        if (!authToken.isEmpty()) {
            debugOutput("Login success: Token obtained");
            QDir currentDir=QDir::current();
            QString dirPath="current";
            if(!currentDir.exists(dirPath))
            {
                if(!currentDir.mkdir(dirPath))
                    return;
            }
            QFile usernameFile(currentDir.filePath(dirPath+"/username.txt"));
            if(!usernameFile.open(QIODevice::WriteOnly | QIODevice::Text))
                return;
            QTextStream usernametxt(&usernameFile);
            usernametxt<<ui->usernameLineEdit->text();
            usernameFile.close();
        } else {
            debugOutput("Login failed: Token not found in response");
        }
    } else {
        debugOutput("Login failed: " + reply->errorString());
    }
}

void LoginWindow::handleSendCaptchaReply(QNetworkReply *reply)
{
    // static bool sendCaptchaReplyHandled = false;
    // if (sendCaptchaReplyHandled) return;
    // sendCaptchaReplyHandled = true;

    debugOutput("Handling send captcha reply");

    ui->sendCaptchaButton->setEnabled(true); // 重新启用按钮

    if (reply->error() == QNetworkReply::NoError) {
        QByteArray responseData = reply->readAll();
        debugOutput("Captcha sent successfully: " + QString(responseData));
    } else {
        debugOutput("Captcha sending failed: " + reply->errorString());
    }
}

void LoginWindow::handleVerifyCaptchaReply(QNetworkReply *reply)
{
    // static bool verifyCaptchaReplyHandled = false;
    // if (verifyCaptchaReplyHandled) return;
    // verifyCaptchaReplyHandled = true;

    debugOutput("Handling verify captcha reply");

    if (reply->error() == QNetworkReply::NoError) {
        QByteArray responseData = reply->readAll();
        debugOutput("Captcha verified successfully: " + QString(responseData));
        MainWindow *w=new MainWindow();
        w->setWindowFlag(Qt::MSWindowsFixedSizeDialogHint);
        w->show();
        this->close();
    } else {
        debugOutput("Captcha verification failed: " + reply->errorString());
    }
}

